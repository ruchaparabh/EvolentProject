﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EmployeeDataConsumeWebApi.Models
{
    public class EmpData
    {
        public int EmployeeId { get; set; }
        [Required(ErrorMessage = "Firstname is required.")]
        public string Firstname { get; set; }
        [Required(ErrorMessage = "Lastname is required.")]
        public string Lastname { get; set; }
        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address.")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Contact is required.")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Invalid contact no")]
        public string Contact { get; set; }
        public EmpStatus Status { get; set; }
        public enum EmpStatus
        {
            Active,
            Inactive
        }
    }
}