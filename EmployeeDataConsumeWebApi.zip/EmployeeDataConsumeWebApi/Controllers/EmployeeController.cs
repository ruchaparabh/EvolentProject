﻿using EmployeeDataConsumeWebApi.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace EmployeeDataConsumeWebApi.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult GetAllEmployee()
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.GetResponse("api/emp/getallemployees");
                response.EnsureSuccessStatusCode();
                List<Models.EmpData> empObj = response.Content.ReadAsAsync<List<Models.EmpData>>().Result;
                ViewBag.Title = "Employee List";
                return View(empObj);
            }
            catch (Exception)
            {
                throw;
            }
        }
        //[HttpGet]  
        public ActionResult EditEmployee(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/emp/GetEmployee?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            Models.EmpData empObj = response.Content.ReadAsAsync<Models.EmpData>().Result;
            ViewBag.Title = "Employee List";
            return View(empObj);
        }
        //[HttpPost]  
        public ActionResult Update(Models.EmpData empObj)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.PutResponse("api/emp/UpdateEmployee", empObj);
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllEmployee");
        }
        public ActionResult Details(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/emp/GetEmployee?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            Models.EmpData empObj = response.Content.ReadAsAsync<Models.EmpData>().Result;
            ViewBag.Title = "Employee List";
            return View(empObj);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
       // [HttpPost]
        public ActionResult Create(Models.EmpData empObj)
        {
            ServiceRepository serviceObj = new ServiceRepository();
           
            HttpResponseMessage response = serviceObj.PostResponse("api/emp/PostEmployee",empObj);
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllEmployee");
        }
        public ActionResult Delete(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.DeleteResponse("api/emp/DeleteEmployee?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllEmployee");
        }
    }
}